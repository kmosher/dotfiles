#!/usr/bin/env python

import setpath
from test_bikefacade import *

if __name__ == "__main__":
    unittest.main()
