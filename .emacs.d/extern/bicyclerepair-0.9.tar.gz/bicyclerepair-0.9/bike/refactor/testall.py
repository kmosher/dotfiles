#!/usr/bin/env python
import setpath
from test_renameMethod import *
from test_renameClass import *
from test_renameFunction import *
from test_rename import *
from test_extractMethod import *
from test_inlineVariable import *
from test_extractVariable import *
from test_moveToModule import *

if __name__ == "__main__":
    unittest.main()
