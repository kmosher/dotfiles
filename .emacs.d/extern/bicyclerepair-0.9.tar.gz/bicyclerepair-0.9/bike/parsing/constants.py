messages={"PARSING":"Parsing","ADDTYPEINFO":"Deducing Type Information"}

MAXCALLDEPTH = 10
