#!/usr/bin/env python
import setpath
import unittest
import compiler
import os

from bike import testdata
from bike.testutils import *
from bike.mock import Mock

from pathutils import getPathOfModuleOrPackage
from load import *
import load as loadmodule



if __name__ == "__main__":
    unittest.main()
